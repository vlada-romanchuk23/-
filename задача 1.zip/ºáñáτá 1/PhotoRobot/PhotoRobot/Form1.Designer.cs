﻿namespace PhotoRobot
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnYoungFace = new System.Windows.Forms.Button();
            this.btnOldFace = new System.Windows.Forms.Button();
            this.lblResult = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnYoungFace
            // 
            this.btnYoungFace.Location = new System.Drawing.Point(45, 50);
            this.btnYoungFace.Name = "btnYoungFace";
            this.btnYoungFace.Size = new System.Drawing.Size(106, 26);
            this.btnYoungFace.TabIndex = 0;
            this.btnYoungFace.Text = "Молоде обличчя";
            this.btnYoungFace.UseVisualStyleBackColor = true;
            this.btnYoungFace.Click += new System.EventHandler(this.btnYoungFace_Click);
            // 
            // btnOldFace
            // 
            this.btnOldFace.Location = new System.Drawing.Point(180, 50);
            this.btnOldFace.Name = "btnOldFace";
            this.btnOldFace.Size = new System.Drawing.Size(103, 26);
            this.btnOldFace.TabIndex = 1;
            this.btnOldFace.Text = "Старе обличчя";
            this.btnOldFace.UseVisualStyleBackColor = true;
            this.btnOldFace.Click += new System.EventHandler(this.btnOldFace_Click);
            // 
            // lblResult
            // 
            this.lblResult.AutoSize = true;
            this.lblResult.Location = new System.Drawing.Point(52, 106);
            this.lblResult.Name = "lblResult";
            this.lblResult.Size = new System.Drawing.Size(59, 13);
            this.lblResult.TabIndex = 2;
            this.lblResult.Text = "Результат";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblResult);
            this.Controls.Add(this.btnOldFace);
            this.Controls.Add(this.btnYoungFace);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnYoungFace;
        private System.Windows.Forms.Button btnOldFace;
        private System.Windows.Forms.Label lblResult;
    }
}

