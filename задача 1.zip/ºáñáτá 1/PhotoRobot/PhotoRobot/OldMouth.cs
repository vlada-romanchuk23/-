﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhotoRobot
{
    public class OldMouth : Mouth
    {
        public override string GetDescription()
        {
            return "Wrinkled and calm mouth";
        }
    }

}
