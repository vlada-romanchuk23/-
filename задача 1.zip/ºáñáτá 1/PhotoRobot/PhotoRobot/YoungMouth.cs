﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhotoRobot
{
    public class YoungMouth : Mouth
    {
        public override string GetDescription()
        {
            return "Fresh and smiling mouth";
        }
    }

}
