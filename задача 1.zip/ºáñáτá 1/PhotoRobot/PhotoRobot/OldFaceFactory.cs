﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhotoRobot
{
    public class OldFaceFactory : IAbstractFactory
    {
        public Eye CreateEye()
        {
            return new OldEye();
        }

        public Nose CreateNose()
        {
            return new OldNose();
        }

        public Mouth CreateMouth()
        {
            return new OldMouth();
        }
    }

}
