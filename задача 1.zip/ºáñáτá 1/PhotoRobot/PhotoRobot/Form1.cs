﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PhotoRobot
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void btnYoungFace_Click(object sender, EventArgs e)
        {
            IAbstractFactory youngFaceFactory = new YoungFaceFactory();
            string result = "Young Face: " +
                            youngFaceFactory.CreateEye().GetDescription() + ", " +
                            youngFaceFactory.CreateNose().GetDescription() + ", " +
                            youngFaceFactory.CreateMouth().GetDescription();

            lblResult.Text = result;
        }

        private void btnOldFace_Click(object sender, EventArgs e)
        {
            IAbstractFactory oldFaceFactory = new OldFaceFactory();
            string result = "Old Face: " +
                            oldFaceFactory.CreateEye().GetDescription() + ", " +
                            oldFaceFactory.CreateNose().GetDescription() + ", " +
                            oldFaceFactory.CreateMouth().GetDescription();

            lblResult.Text = result;
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
