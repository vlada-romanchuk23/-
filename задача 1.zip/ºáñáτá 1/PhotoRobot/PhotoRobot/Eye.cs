﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhotoRobot
{
    public abstract class Eye
    {
        public abstract string GetDescription();
    }

}
