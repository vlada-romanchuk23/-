﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhotoRobot
{
    public class YoungFaceFactory : IAbstractFactory
    {
        public Eye CreateEye()
        {
            return new YoungEye();
        }

        public Nose CreateNose()
        {
            return new YoungNose();
        }

        public Mouth CreateMouth()
        {
            return new YoungMouth();
        }
    }

}
