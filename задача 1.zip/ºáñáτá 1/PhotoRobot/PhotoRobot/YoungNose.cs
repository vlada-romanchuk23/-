﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhotoRobot
{
    public class YoungNose : Nose
    {
        public override string GetDescription()
        {
            return "Small and sharp nose";
        }
    }

}
