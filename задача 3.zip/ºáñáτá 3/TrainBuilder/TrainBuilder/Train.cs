﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrainBuilder
{
    public class Train
    {
        public string Engine { get; set; }
        public int PassengerCars { get; set; }
        public int CargoCars { get; set; }

        public void DisplayInfo()
        {
            Console.WriteLine($"Train with {Engine}, {PassengerCars} passenger cars and {CargoCars} cargo cars.");
        }
    }

}
