﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrainBuilder
{
    public class TrainDirector
    {
        private ITrainBuilder _builder;

        public TrainDirector(ITrainBuilder builder)
        {
            _builder = builder;
        }

        public Train Construct()
        {
            _builder.BuildEngine();
            _builder.BuildPassengerCars(10);
            _builder.BuildCargoCars(5);
            return _builder.GetResult();
        }
    }

}
