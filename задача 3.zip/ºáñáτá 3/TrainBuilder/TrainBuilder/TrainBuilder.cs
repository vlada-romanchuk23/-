﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrainBuilder
{
    public interface ITrainBuilder
    {
        void BuildEngine();
        void BuildPassengerCars(int numberOfCars);
        void BuildCargoCars(int numberOfCars);
        Train GetResult();
    }

}
