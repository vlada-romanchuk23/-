﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TrainBuilder
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void btnCreateTrain_Click(object sender, EventArgs e)
        {
            // Створюємо будівельника потягів
            ITrainBuilder builder = new ConcreteTrainBuilder();
            TrainDirector director = new TrainDirector(builder);

            // Будуємо потяг
            Train train = director.Construct();

            // Виводимо інформацію про потяг у Label
            lblResult.Text = $"Потяг створено: {train.Engine}, " +
                             $"{train.PassengerCars} пасажирських вагонів, " +
                             $"{train.CargoCars} вантажних вагонів.";
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
