﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrainBuilder
{
    public class ConcreteTrainBuilder : ITrainBuilder
    {
        private Train _train = new Train();

        public void BuildEngine()
        {
            _train.Engine = "Diesel Engine";
        }

        public void BuildPassengerCars(int numberOfCars)
        {
            _train.PassengerCars = numberOfCars;
        }

        public void BuildCargoCars(int numberOfCars)
        {
            _train.CargoCars = numberOfCars;
        }

        public Train GetResult()
        {
            return _train;
        }
    }

}
