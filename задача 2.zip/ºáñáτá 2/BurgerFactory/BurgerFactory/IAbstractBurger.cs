﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BurgerFactory
{
    public interface IAbstractBurger
    {
        void Prepare(Label lblResult);
        void Cook(Label lblResult);
        void Serve(Label lblResult);
    }


}
