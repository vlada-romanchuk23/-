﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BurgerFactory
{
    public class VegetarianBurger : IAbstractBurger
    {
        public void Prepare(Label lblResult)
        {
            lblResult.Text += "Preparing vegetarian burger...\n"; // добавляем к тексту
        }

        public void Cook(Label lblResult)
        {
            lblResult.Text += "Cooking vegetarian burger...\n";
        }

        public void Serve(Label lblResult)
        {
            lblResult.Text += "Serving vegetarian burger...\n";
        }
    }

}
