﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BurgerFactory
{
    public class MeatBurger : IAbstractBurger
    {
        public void Prepare(Label lblResult)
        {
            lblResult.Text += "Preparing meat burger...\n";
        }

        // Реализация метода Cook
        public void Cook(Label lblResult)
        {
            lblResult.Text += "Cooking meat burger...\n";
        }

        // Реализация метода Serve
        public void Serve(Label lblResult)
        {
            lblResult.Text += "Serving meat burger...\n";
        }

    }
}
